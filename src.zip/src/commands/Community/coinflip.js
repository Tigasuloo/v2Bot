const { 
    SlashCommandBuilder 
} = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
    .setName("flip")
    .setDescription("Flip a coin."),

    async execute(interaction) {

        const choices = ["Head", "Tail"]
        const randomChoice = choices[Math.floor(Math.random()*choices.length)];

        await interaction.reply({ content: `${randomChoice}`})
    }
};