const { 
    SlashCommandBuilder, 
    EmbedBuilder 
  } = require('discord.js');
  
  module.exports = {
      data: new SlashCommandBuilder()
          .setName('presence')
          .setDescription('Fetches a user\'s current presence')
          .addUserOption(option => 
              option.setName('user')
              .setDescription('The user whose presence you want to fetch.')
              .setRequired(true)
          ),
      async execute(interaction) {
          const user = interaction.options.getUser('user');
          const member = interaction.guild.members.cache.get(user.id);
          const presence = member?.presence || {};
          let status;
  
          if (presence.status === 'online') {
              status = 'Online';
          } else if (presence.status === 'idle') {
              status = 'Idle';
          } else if (presence.status === 'dnd') {
              status = 'Do Not Disturb';
          } else {
              status = 'Offline';
          }
  
          const embed = new EmbedBuilder()
              .setTitle(`Presence`)
              .setColor("Black")
              .setThumbnail(user.displayAvatarURL())
              .addFields(
                { name: 'User', value: `${user}` },
                { name: 'Status', value: status }
              );
  
          await interaction.reply({ embeds: [embed] });
      },
  };