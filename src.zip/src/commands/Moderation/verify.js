const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, Emoji } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription("verification")

        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title of embed')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('description')
                .setDescription('description of embed')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('colour')
                .setDescription('Colour of embed')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('label')
                .setDescription('nazwa przycisku')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('rola')
                .setRequired(true)
        ),

    async execute (interaction, client) {
        const label = interaction.options.getString('label');
        const title = interaction.options.getString('title');
        const colour = interaction.options.getString('colour');
        const description = interaction.options.getString('description');
        const role = interaction.options.getRole('role');

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({ content: "You must be an admin to create a verification message", ephemeral: true});

        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('button')
            .setEmoji(`✅`)
            .setLabel(`${label}`)
            .setStyle(ButtonStyle.Success),
        )

        const embed = new EmbedBuilder()
        .setColor(`${colour}`)
        .setTitle(`${title}`)
        .setDescription(`${description}`)
        .setFooter({ text: `© Owner : 𝟏𝟑Ҝ#0001 | ${interaction.guild}` })
        .setImage('https://cdn.discordapp.com/attachments/945198364075634728/1081775752573366342/XIII.gif')

        await interaction.reply({ embeds: [embed], components: [button] });

        const collector = await interaction.channel.createMessageComponentCollector();

        collector.on('collect', async i => {

            await i.update({ embeds: [embed], components: [button] });



            const member = i.member

            member.roles.add(role);

            i.user.send(`You are now verified within **${i.guild.name}**`).catch(err => {
                return;
            });
        })
    }
}