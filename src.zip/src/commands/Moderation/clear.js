const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');
 
module.exports = {
    data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Delete a specific number of messages from a channel')
    .addIntegerOption(option => option.setName('amount').setDescription('The ammount of messages to delete').setMinValue(1).setMaxValue(100).setRequired(true)),
    async execute (interaction, client) {

        const amount = interaction.options.getInteger('amount');
        const channel = interaction.channel;

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return await interaction.reply({ content: "You don't hace a permission to execute this command", ephemeral: true });
        if (!amount) return await interaction.reply({ content: "Please specity the ammount of messages you want to delete", ephemeral: true});
        if (amount > 100 || amount < 1) return await interaction.reply({ content: "Please select a number *between* 100 and 1", ephemeral: true});

        await interaction.channel.bulkDelete(amount).catch(err => {
            return;
        });

        const embed = new SlashCommandBuilder()
            //.setColor("Black")
            .setDescription(` :white_check_mark: Deleted **${amount}** messages.`)

            await interaction.reply({ embeds: [embed] }).catch (err => {
                return;
            })
    }
} 