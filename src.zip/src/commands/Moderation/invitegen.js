const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
data: new SlashCommandBuilder()
    .setName('instantinvite')
    .setDescription('create an instant invite for your server'),
async execute(interaction, guild) {
    
    const channel = interaction.guild.channels.cache.filter((channel) => channel.type === ChannelType.GuildText).first();
    const invite = await channel.createInvite({ maxAge: 0, maxUses: 0 })


    const embed = new EmbedBuilder()
    .setColor("Black")
    .setAuthor({ name: 'Success', iconURL: interaction.guild.iconURL({ dynamic: true})})
    .setDescription('This invite link will never expire')
    .addFields({ name: 'Invite', value: `${invite}`})
    .setFooter({ text: `© Owner : 𝟏𝟑Ҝ#0001 | ${interaction.guild}` })
    .setImage('https://cdn.discordapp.com/attachments/945198364075634728/1081775752573366342/XIII.gif')
    .setTimestamp()

    await interaction.reply({ embeds: [embed] })
    }
};