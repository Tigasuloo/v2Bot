const { SlashCommandBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName("leaveserver")
    .setDescription("make the bot leave a server")
    .addStringOption(option =>
      option.setName("serverid")
          .setDescription("serverid")
          .setRequired(true)
    ),
                   
                    async execute(interaction, client) {

                      if(interaction.member.id !== '906025160690245695') return interaction.reply({ content: 'this command is locked under the owner', ephemeral: true})

                      interaction.reply({content:'the bot has left this server', ephemeral: true})

                      const guildid = interaction.options.getString("guildid");

                      const guild = client.guilds.cache.get(guildid)

                      guild.leave().catch(() => {
                    return false;
                    });

                    }
}